package com.imooc.zoo;

public interface IAct {
    void skill();
    void act();
}
